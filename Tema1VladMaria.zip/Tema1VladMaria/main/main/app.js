const compress = (a, b = true) => {
	//TODO: implementați funcția
	// TODO: implement the function
	//a este string-ul primit
	//b este un boolean
	//b = true => compresie
	//b = false => decompresie

	//cerinta 3
	if (typeof a != 'string'){
		throw new Error('InvalidType');
	}
	
	//cerinta 1
	if(a === '') return '';

	let rezultat = '';
	let contor = 1;
	let i = 0;
	
	//cerinta 2 si 5
	if (b === true){
		while(i < a.length){
			while(a[i] === a[i+contor]) contor++;
			rezultat = rezultat + a[i] + contor.toString();
			i += contor;
			contor = 1;
		}
		return rezultat;
	}//cerinta 4
	else if (b === false){
		while(i < a.length){
			let charNum = parseInt(a[i+1]);
			rezultat = rezultat.padEnd(rezultat.length + charNum, a[i]);
			i += 2;
		}
		return rezultat;
	}
}

module.exports = compress